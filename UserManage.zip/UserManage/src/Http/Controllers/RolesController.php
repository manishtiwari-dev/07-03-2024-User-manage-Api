<?php

namespace Modules\UserManage\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\UserManage\Models\Role;
use Modules\UserManage\Models\RoleToPermission;
use Illuminate\Support\Str;
use DB;
use App\Models\Module;
use App\Models\ModuleSection;
use Modules\UserManage\Models\Permission;


class RolesController extends Controller
{
    public $page = 'role';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';



    /*  sectionList */
    public function section_list(Request $request)
    {
        $api_token = $request->api_token;
        $language = $request->language;
        $userType = $request->userType;
        $module_listItem = [];
        $sectionList = [];
        $usType = ($userType == 'administrator') ? 0 : 2;
        $utype = '1,' . $usType;

        $industry_id = ApiHelper::get_industry_id_by_api_token($api_token);

        if ($userType == 'subscriber') {

            $moduleList = Module::with(['section_list' => function ($query) {
                $query->orderBy('sort_order', 'ASC')->where('status', 1);
            }])->whereRelation('module_list', 'industry_id',  $industry_id)->whereRaw('access_priviledge IN(' . $utype . ')')->where('status', '1')->orderBy('sort_order', 'ASC')->get();

            $moduleList = $moduleList->map(function ($data) use ($language) {


                $cate = $data->section_list()->where('status', 1)->orWhere('sort_order', 'ASC')->first();

                $data->section_name = ($cate == null) ? '' : $cate->section_name;




                return $data;
            });
        } else {


            $moduleList = Module::with(['section_list' => function ($query) {
                $query->orderBy('sort_order', 'ASC')->where('status', 1)->where('parent_section_id', 0);
            }])->whereRaw('access_priviledge IN(' . $utype . ')')->where('status', '1')->orderBy('sort_order', 'ASC')->get();



            $moduleList = $moduleList->map(function ($data) use ($language) {


                $cate = $data->section_list()->where('status', 1)->where('parent_section_id', 0)->orderBy('sort_order', 'ASC')->first();

                $data->section_name = ($cate == null) ? '' : $cate->section_name;




                return $data;
            });
        }


        $module_listItem['module_list'] =  $moduleList;
        $module_listItem['permission_list'] = Permission::where('status', 1)->get();
        return ApiHelper::JSON_RESPONSE(true, $module_listItem, '');
    }

    public function roles_all(Request $request)
    {

        $api_token = $request->api_token;

        $roles_list = Role::all();

        return ApiHelper::JSON_RESPONSE(true, $roles_list, '');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        // get all request val
        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;


        $data_query = Role::query();

        // search
        if (!empty($search))
            $data_query = $data_query->where("roles_name", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('sort_order', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;     // apply page logic

        $data_count = $data_query->count(); // get total count

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        // get pagination data
        $data_list = $data_list->map(function ($data) {

            $sectionlist = ApiHelper::byRoleIdSectionsPermissionList($data->roles_id);
            $data->permissionList = $sectionlist;
            $data->userCount = $data->users()->count();
            return $data;
        });

        // section list

        $userType = $request->userType;
        $module_listItem = [];
        $sectionList = [];
        $usType = ($userType == 'administrator') ? 0 : 2;
        $utype = '1,' . $usType;

        $industry_id = ApiHelper::get_industry_id_by_api_token($api_token);

        if ($userType == 'subscriber') {

            $moduleList = Module::with(['section_list' => function ($query) {
                $query->orderBy('sort_order', 'ASC')->where('status', 1);
            }])->whereRelation('module_list', 'industry_id',  $industry_id)->whereRaw('access_priviledge IN(' . $utype . ')')->where('status', '1')->orderBy('sort_order', 'ASC')->get();

            $moduleList = $moduleList->map(function ($data) {


                $cate = $data->section_list()->where('status', 1)->orWhere('sort_order', 'ASC')->first();

                $data->section_name = ($cate == null) ? '' : $cate->section_name;




                return $data;
            });
        } else {


            $moduleList = Module::with(['section_list' => function ($query) {
                $query->orderBy('sort_order', 'ASC')->where('status', 1)->where('parent_section_id', 0);
            }])->whereRaw('access_priviledge IN(' . $utype . ')')->where('status', '1')->orderBy('sort_order', 'ASC')->get();



            $moduleList = $moduleList->map(function ($data) {


                $cate = $data->section_list()->where('status', 1)->where('parent_section_id', 0)->orderBy('sort_order', 'ASC')->first();

                $data->section_name = ($cate == null) ? '' : $cate->section_name;




                return $data;
            });
        }


        $module_listItem['module_list'] =  $moduleList;
        $module_listItem['permission_list'] = Permission::where('status', 1)->get();



        $res = [
            'data' => $data_list,
            'module_listItem' => $module_listItem,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $user_id = ApiHelper::get_adminid_from_token($api_token);

        $role_name = $request->role_name;
        // $sort_order = $request->sort_order;

        $max_sortOrder =  Role::max('sort_order');
        $sort_order = $max_sortOrder + 1;



        $status = Role::where('roles_key', Str::slug($role_name))->first();

        if ($status !== null)    return ApiHelper::JSON_RESPONSE(false, [], 'ROLE_EXISTS');

        $role = Role::create([
            'roles_name' => $role_name,
            'sort_order' => $sort_order,
            'roles_key' => Str::slug($role_name)
        ]);

        $permissionList = [];
        $sectionList = [];

        $findDif = '';


        // if (sizeof($request->formData) > 0) {
        //     foreach ($request->formData as $sectionId => $permission) {

        //         if (!empty($permission)) {


        //             foreach ($permission as $pId => $pTyeId) {

        //                 if (!empty($pTyeId)) {
        //                     array_push($permissionList, [
        //                         'section_id' => (int) $sectionId,
        //                         'roles_id' => $role->roles_id,
        //                         'permissions_ids' => (int)$pId,
        //                         'permission_types_id' => (int)$pTyeId,
        //                     ]);
        //                 }
        //             }
        //         }
        //     }
        // }



        $section_list = ModuleSection::where('status', 1)->get();
        $permission_list = Permission::where('status', 1)->get();

        foreach ($section_list as $secKey => $secVal) {
            foreach ($permission_list as $perKey => $per_list) {
                $section_id = $secVal->section_id;
                $per_id =  $per_list->permissions_id;
                $pTyeId = '';
                $pTyeId =  "permission_" . $section_id . "_" . $per_id;
                if (array_key_exists($pTyeId, $request->formData)) {
                    $saveData = $request->formData[$pTyeId];


                    if (!empty($saveData)) {
                        array_push($permissionList, [
                            'section_id' => (int) $section_id,
                            'roles_id' => $role->roles_id,
                            'permissions_ids' => (int)$per_id,
                            'permission_types_id' =>   $saveData,
                        ]);
                    }
                }
            }
        }



        $role->sections()->attach($permissionList);


        if ($role)   return ApiHelper::JSON_RESPONSE(true, $sectionList, 'ROLE_CREATED');
        else return ApiHelper::JSON_RESPONSE(false, [], 'UNABLE_CREATE_ROLE');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $api_token = $request->api_token;
        $language = $request->language;
        $module_listItem = [];

        //   $moduleList=[];

        $sectionList = [];

        $usType = ($request->userType == 'administrator') ? 0 : 2;

        $utype = '1,' . $usType;




        $industry_id = ApiHelper::get_industry_id_by_api_token($api_token);

        $moduleList = Module::with(['section_list' => function ($query) {
            $query->orderBy('sort_order', 'ASC')->where('status', 1);
        }])->whereRelation('module_list', 'industry_id',  $industry_id)->whereRaw('access_priviledge IN(' . $utype . ')')->where('status', '1')->orderBy('sort_order', 'ASC')->get();
        // if(!empty($module)){
        //     foreach ($module as $key => $mod) {

        //         array_push($moduleList, $mod);

        //         if(!empty($mod->section_list)){
        //             foreach ($mod->section_list as $key => $value) {
        //                 array_push($sectionList, $value);    
        //             }
        //         }
        //     }
        // }

        $moduleList = $moduleList->map(function ($data) use ($language) {


            $cate = $data->section_list()->where('status', 1)->orWhere('sort_order', 'ASC')->first();

            $data->section_name = ($cate == null) ? '' : $cate->section_name;




            return $data;
        });


        $module_listItem['module_list'] =  $moduleList;
        $module_listItem['permission_list'] = Permission::where('status', 1)->get();
        //$module_listItem['permission_list'] =RoleToPermission::with('permission_info')->find($request->updateId);
        return ApiHelper::JSON_RESPONSE(true, $module_listItem, '');
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $role_list = Role::with('permissionsTypeList')->find($request->updateId);


        // section list

        $userType = $request->userType;
        $module_listItem = [];
        $sectionList = [];
        $usType = ($userType == 'administrator') ? 0 : 2;
        $utype = '1,' . $usType;

        $industry_id = ApiHelper::get_industry_id_by_api_token($api_token);
        // section list
        if ($userType == 'subscriber') {

            $moduleList = Module::with(['section_list' => function ($query) {
                $query->orderBy('sort_order', 'ASC')->where('status', 1);
            }])->whereRelation('module_list', 'industry_id',  $industry_id)->whereRaw('access_priviledge IN(' . $utype . ')')->where('status', '1')->orderBy('sort_order', 'ASC')->get();

            $moduleList = $moduleList->map(function ($data) {


                $cate = $data->section_list()->where('status', 1)->orWhere('sort_order', 'ASC')->first();

                $data->section_name = ($cate == null) ? '' : $cate->section_name;




                return $data;
            });
        } else {


            $moduleList = Module::with(['section_list' => function ($query) {
                $query->orderBy('sort_order', 'ASC')->where('status', 1)->where('parent_section_id', 0);
            }])->whereRaw('access_priviledge IN(' . $utype . ')')->where('status', '1')->orderBy('sort_order', 'ASC')->get();



            $moduleList = $moduleList->map(function ($data) {


                $cate = $data->section_list()->where('status', 1)->where('parent_section_id', 0)->orderBy('sort_order', 'ASC')->first();

                $data->section_name = ($cate == null) ? '' : $cate->section_name;




                return $data;
            });
        }
        // end section list

        //selected permission
        $permissionArray = [];

        $section_list = ModuleSection::where('status', 1)->get();
        $permission_list = Permission::where('status', 1)->get();


        if (!empty($role_list->permissionsTypeList)) {
            foreach ($role_list->permissionsTypeList as $pTyeId) {
                $permissionArray[$pTyeId->section_id][$pTyeId->permissions_ids] = $pTyeId;
            }
        }




        $module_listItem['module_list'] =  $moduleList;
        $module_listItem['permission_list'] = Permission::where('status', 1)->get();

        $res = [
            'role_list' => $role_list,
            'module_listItem' => $module_listItem,
            'permissionArray' => $permissionArray,


        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');


        // $role_list->sections = ApiHelper::byRoleIdSectionsPermissionList($role_list->roles_id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */



    public function sortOrder(Request $request)
    {
        $api_token = $request->api_token;
        $roles_id = $request->roles_id;
        $sort_order = $request->sort_order;

        $infoData =  Role::find($roles_id);
        if (empty($infoData)) {
            $infoData = new Role();
            $infoData->roles_id = $roles_id;
            $infoData->sort_order = $sort_order;
            $infoData->status = 1;

            $infoData->save();
        } else {
            $infoData->sort_order = $sort_order;
            $infoData->save();
        }

        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_SORT_ORDER_UPDATE');
    }







    public function update(Request $request)
    {
        // return ApiHelper::JSON_RESPONSE(true, $request->all(), 'PAGE_ACCESS_DENIED');

        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $user_id = ApiHelper::get_adminid_from_token($api_token);

        $role_name = $request->role_name;
        //$sort_order = $request->sort_order;

        $roles = Role::where('roles_name', $role_name)->first();


        // if new role coming than will update else not
        if (empty($roles)) {
            Role::where('roles_id', $request->formData['updateId'])->update(['roles_name' => $role_name, 'roles_key' => Str::slug($role_name),]);
        }

        // $roles = Role::find($request->formData['updateId']);
        $role = Role::where('roles_id', $request->formData['updateId'])->first();

        //  return ApiHelper::JSON_RESPONSE(true, $roles, 'PAGE_ACCESS_DENIED');
        // role permission updated
        $permissionList = [];


        $section_list = ModuleSection::where('status', 1)->get();
        $permission_list = Permission::where('status', 1)->get();

        if (sizeof($request->formData) > 0) {
            $role->sections()->detach();    // detach relationship data 

            foreach ($section_list as $secKey => $secVal) {
                foreach ($permission_list as $perKey => $per_list) {
                    $section_id = $secVal->section_id;
                    $per_id =  $per_list->permissions_id;
                    $pTyeId = '';
                    $pTyeId =  "permission_" . $section_id . "_" . $per_id;
                    if (array_key_exists($pTyeId, $request->formData)) {
                        $saveData = $request->formData[$pTyeId];


                        if (!empty($saveData)) {
                            array_push($permissionList, [
                                'section_id' => (int) $section_id,
                                'roles_id' => $role->roles_id,
                                'permissions_ids' => (int)$per_id,
                                'permission_types_id' =>   $saveData,
                            ]);
                        }
                    }
                }
            }
        }
        $role->sections()->attach($permissionList);         // attach permission list

        // if (sizeof($request->permission) > 0) {

        //     $role->sections()->detach();    // detach relationship data 

        //     foreach ($request->permission as $sectionId => $permission) {

        //         if (!empty($permission)) {

        //             foreach ($permission as $pId => $pTyeId) {

        //                 if (!empty($pTyeId)) {
        //                     array_push($permissionList, [
        //                         'section_id' => (int) $sectionId,
        //                         'roles_id' => $role->roles_id,
        //                         'permissions_ids' => (int)$pId,
        //                         'permission_types_id' => (int)$pTyeId,
        //                     ]);
        //                 }
        //             }
        //         }
        //     }
        //     $role->sections()->attach($permissionList);         // attach permission list
        // }

        if ($role)   return ApiHelper::JSON_RESPONSE(true, $role, 'ROLE_UPDATED');
        else return ApiHelper::JSON_RESPONSE(false, [], 'UNABLE_UPDATE_ROLE');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->deleteId;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $role = Role::find($id);
        $role->sections()->detach();
        $status = Role::destroy($id);
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'ROLE_DELETED');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'NOT_DELETED_ROLE');
        }
    }
}
