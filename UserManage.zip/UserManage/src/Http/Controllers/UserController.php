<?php

namespace Modules\UserManage\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserBusiness;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Modules\UserManage\Models\Role;


class UserController extends Controller
{
    public $page = 'user';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';



    /* get all userlist */
    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;


        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        //  $user_query = User::query();
        $user_query = User::whereHas('roles', function ($query) {
            $query->where('roles_key', '!=', 'super_admin');
        });

        // attaching query filter by permission(all, added,owned,both)
        $user_query = ApiHelper::attach_query_permission_filter($user_query, $api_token, $this->page, $this->pageview);

        if (!empty($search)) {
            $user_query = $user_query->where("first_name", "LIKE", "%{$search}%")->where("last_name", "LIKE", "%{$search}%")->orWhere("email", "LIKE", "%{$search}%");
        }

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $user_query = $user_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $user_query = $user_query->orderBy('id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

        $user_count = $user_query->count();

        $user_list = $user_query->skip($skip)->take($perPage)->get();

        $user_list = $user_list->map(function ($user) {
            $user->full_image_path = Storage::path($user->profile_photo);

            $user->role_name = ApiHelper::get_role_name_from_token($user->api_token);
            $user->name = $user->first_name . ' ' . $user->last_name;
            // if (isset($user->roles[0])) {
            //     if ($user->roles[0]->roles_key == 'super_admin') {
            //         $user->role_name = $user->roles[0]->roles_key;
            //     }
            // }
            return $user;
        });

        $roles_list = Role::all();


        $res = [
            'data' => $user_list,
            'roles_list' => $roles_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int) $user_count / (int) $perPage),
            'per_page' => $perPage,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /* create user and assign role  */
    public function store(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }
        // $subs_id = ApiHelper::get_subscription_id_by_api_token($request->api_token);
        //  return ApiHelper::JSON_RESPONSE(true, $request->all(), 'PAGE_ACCESS_DENIED');
        // validation check
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:usr_users',
            'password' => 'required|string|min:8',
            'role_name' => 'required',
        ], [
            'name.required' => 'NAME_REQUIRED',
            'name.max' => 'NAME_MAX',
            'email.required' => 'EMAIL_REQUIRED',
            'email.email' => 'EMAIL_EMAIL',
            'password.required' => 'PASSWORD_REQUIRED',
            'password.min' => 'PASSWORD_MIN',
            'role.required' => 'ROLE_NAME_REQUIRED',
        ]);

        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }

        try {

            DB::beginTransaction(); // begin transaction

            // store user and assign role
            $user = User::create([
                'first_name' => $request->name,
                'last_name' => '',
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'created_by' => ApiHelper::get_adminid_from_token($request->api_token),
                'api_token' => Hash::make($request->name),
            ]);
            // attach role
            $user->roles()->attach($request->role_name);

            //if user is subscriber replica of user store in userbusiness
            if ($request->has('userType') && $request->userType == 'subscriber') {
                $parent_id = ApiHelper::get_adminid_from_token($request->api_token);

                $userBusiness = UserBusiness::where('users_id', $parent_id)->first();
                $newBusinnens = $userBusiness->replicate();
                $newBusinnens->users_id = $user->id;
                $newBusinnens->subscription_id = ApiHelper::get_subscription_id_by_api_token($request->api_token);

                $newBusinnens->users_email = $user->email;
                $newBusinnens->created_at = date('Y-m-d h:s:i');
                $newBusinnens->save();
            }

            DB::commit(); // db commit

            return ApiHelper::JSON_RESPONSE(true, $user, 'SUCCESS_USER_ADD');
        } catch (\Throwable $th) {
            \Log::error($th->getMessage());
            DB::rollback(); // db rollback
            return ApiHelper::JSON_RESPONSE(false, [], "HAVING_SOME_TECHNICAL_ISSUE");
        }
    }

    public function edit(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        // $user = User::where('api_token', $api_token)->first();
        // $section = ApiHelper::get_permission_list( $api_token);
        // return ApiHelper::JSON_RESPONSE(false, $section, 'PAGE_ACCESS_DENIED');

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $userdetail = User::find($request->user_id);
        if ($userdetail != null) {

            /* $userdetail->full_image_path = asset('storage/'.$userdetail->image_path);*/
            // $userdetail->full_image_path = (!empty($userdetail->profile_photo)) ? Storage::url($userdetail->profile_photo) : '';


            $userdetail->full_image_path = ApiHelper::getFullImageUrl($userdetail->profile_photo, 'index-list');

            if (isset($userdetail->roles[0])) {
                $userdetail->role_name = $userdetail->roles[0]->name;
                $userdetail->role_id = $userdetail->roles[0]->role_id;
            } else {
                $userdetail->role_name = '';
            }

            $roles_list = Role::all();


            $res = [
                'userdetail' => $userdetail,
                'roles_list' => $roles_list,

            ];
            return ApiHelper::JSON_RESPONSE(true, $res, '');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'SOMETHING_WRONG');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // return ApiHelper::JSON_RESPONSE(true,$request->file('profileimg'),'Profile updated successfully !');
        // Validate user page access
        $api_token = $request->api_token;
        $user_id = $request->user_id;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        // validation check
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            // 'contact' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
            'contact' => 'required',
            'date_of_birth' => 'required|date',
            'gender' => 'required',
        ], [
            'first_name.required' => 'NAME_REQUIRED',
            'first_name.max' => 'NAME_MAX',
            'contact.required' => 'CONTACT_REQUIRED',
            'date_of_birth.required' => 'DOB_REQUIRED',
            'gender.required' => 'GENDER_REQUIRED',
        ]);

        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }

        $updateData = $request->only('first_name', 'last_name', 'contact', 'date_of_birth', 'gender', 'profile_photo');
        if ($request->has('userpassword') && !empty($request->userpassword)) {
            $updateData['password'] = Hash::make($request->userpassword);
        }

        // if ($request->has("profileimg")) {
        //     if ($request->file('profileimg')) {

        //         ApiHelper::image_upload_with_crop($api_token,  $updateData['profile_photo'], 1, 'profile_photo', '', false);

        //         // $updateData['profile_photo'] = $request->file('profileimg')->store('media/profile_photo');
        //     }
        // }


        if ($request->has("profile_photo") && !empty($request->profile_photo)) {
            ApiHelper::image_upload_with_crop(
                $api_token,
                $updateData['profile_photo'],
                1,
                'user/profile',
                '',
                false
            );
        }



        $userInfo = User::find($user_id);

        // $autoGenPass = rand();
        // if($request->has('autoGenerate')){
        //     if($request->autoGenerate == 'on'){

        //         $updateData['password'] = Hash::make($autoGenPass);
        //         // sent auto generate password to mail
        //         // Mail::to($userInfo->email)->queue(new AutoGeneratePassword($autoGenPass));
        //         $arralist = [
        //             'email'=>$userInfo->email,
        //             'autoGenPass'=>$autoGenPass
        //         ];
        //         dispatch(new SendAutoGeneratePasswordMail($arralist));

        //     }
        // }


        $status = $userInfo->update($updateData);

        if ($request->has('role_name') && !empty($request->role_name)) {
            $user = User::find($user_id);
            $user->roles()->detach();
            $user->roles()->attach($request->role_name);
        }

        $userInfo = User::find($user_id);

        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, $userInfo, 'SUCCESS_PROFILE_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_PROFILE_UPDATE');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->deleteId;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $status = User::destroy($id);
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_USER_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_USER_DELETE');
        }
    }




    /* change status */

    public function changeStatus(Request $request)
    {
        try {
            $sub_data = User::find($request->user_id);
            $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
            $sub_data->save();
            return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
        } catch (\Throwable $th) {
            return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SOME_TECHNICAL_ISSUE');
        }
    }

    /* update user info */

    public function updateUser(Request $request)
    {
        //return ApiHelper::JSON_RESPONSE(true,$request->all(),'SUCCESS_USER_UPDATE');
        // Validate user page access
        $api_token = $request->api_token;
        $user_id = $request->user_id;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        // validation check
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'role_name' => 'required',
        ], [
            'name.required' => 'NAME_REQUIRED',
            'name.max' => 'NAME_MAX',
            'role.required' => 'ROLE_NAME_REQUIRED',
        ]);

        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }

        try {

            DB::beginTransaction(); // begin transaction

            // $storeData['first_name']= $request->name;
            //    return ApiHelper::JSON_RESPONSE(false, $storeData , 'EMAIL_UNIQUE_REQUIRED');
            $storeData = ['email' => $request->email, 'first_name' => $request->name];

            if (!empty($request->password)) {
                $storeData['password'] = Hash::make($request->password);
            }

            // store user and assign role

            $users = User::where('email', $request->email)->whereNotIn('id', [$user_id])->first();

            if (empty($users)) {
                User::where('id', $user_id)->update($storeData);
            } else {

                return ApiHelper::JSON_RESPONSE(false, [], 'EMAIL_UNIQUE_REQUIRED');
            }

            //  User::where('id', $user_id)->update($storeData);

            $user = User::where('id', $user_id)->first();

            if (!empty($request->role_name)) {
                $user->roles()->detach(); // remove old role
                $user->roles()->attach($request->role_name); // attach new role
            }

            DB::commit(); // db commit

            return ApiHelper::JSON_RESPONSE(true, $user, 'SUCCESS_USER_UPDATE');
        } catch (\Throwable $th) {
            \Log::error($th->getMessage());
            DB::rollback(); // db rollback
            return ApiHelper::JSON_RESPONSE(false, [], json_encode($th->getMessage()));
        }
    }
}
