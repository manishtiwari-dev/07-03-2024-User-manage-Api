<?php

namespace Modules\UserManage\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RoleToPermission extends Model
{
    use HasFactory;
    public function getTable()
    {
        return config('dbtable.common_role_has_permissions');
    }
    public $timestamps = false;
    protected $fillable = [
        'section_id',
        'permissions_ids',
        'roles_id',
        'permission_types_id',
    ];

    public function permission_info()
    {
        return $this->belongsTo(Permission::class, 'permissions_ids', 'id');
    }
}
