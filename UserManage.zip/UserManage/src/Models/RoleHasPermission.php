<?php

namespace Modules\UserManage\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RoleHasPermission extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $guarded = [];
    public function getTable()
    {
        return config('dbtable.common_role_has_permissions');
    }
}
