<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\UserManage\Http\Controllers\RolesController;
use Modules\UserManage\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::group(['middleware' => ['ApiTokenCheck'], 'prefix' => "api/"], function () {



    Route::post('users', [UserController::class, 'index']);
    Route::post('user/edit', [UserController::class, 'edit']);
    Route::post('user/store', [UserController::class, 'store']);
    Route::post('user/update', [UserController::class, 'update']);
    Route::post('user/delete', [UserController::class, 'destroy']);
    Route::post('user/changeStatus', [UserController::class, 'changeStatus']);
    Route::post('user/updateUser', [UserController::class, 'updateUser']);




    Route::post('roles', [RolesController::class, 'index']);
    Route::post('/roles/section_list', [RolesController::class, 'section_list']);
    Route::post('role/store', [RolesController::class, 'store']);
    Route::post('role/edit', [RolesController::class, 'edit']);
    Route::post('role/view', [RolesController::class, 'show']);

    Route::post('role/update', [RolesController::class, 'update']);
    Route::post('role/delete', [RolesController::class, 'destroy']);
    Route::post('role/sortOrder', [RolesController::class, 'sortOrder']);
    Route::post('rolesAll', [RolesController::class, 'roles_all']);
});
